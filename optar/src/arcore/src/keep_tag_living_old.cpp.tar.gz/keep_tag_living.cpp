#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>
#include "std_msgs/String.h"


static std::string nameTag;

static bool canStamp;
static std_msgs::Header head_tag;
static tf::Vector3 tran_tag;
static tf::Quaternion quat_tag;

void listenerTag(const geometry_msgs::PoseArray::ConstPtr& msg)
{
  try
  {
    tf::Transform transform;
    static tf::TransformBroadcaster br;

    if(msg->poses.size() == 0)
    {
      if(canStamp)
      {
        head_tag.stamp = ros::Time::now();

        transform.setOrigin( tran_tag );
        transform.setRotation( quat_tag );

        br.sendTransform(tf::StampedTransform(transform, head_tag.stamp, head_tag.frame_id, nameTag));

        ROS_WARN("TAG -> Published tag pose from previous real revelation seq# %d", head_tag.seq);

        return;
      }
      else
      {  
        ROS_WARN("TAG -> No tag detected. Waiting first tag detection...");
      }
      return;
    }

    head_tag = msg->header;
    tran_tag = tf::Vector3(msg->poses[0].position.x, msg->poses[0].position.y, msg->poses[0].position.z);
    quat_tag = tf::Quaternion(msg->poses[0].orientation.x, msg->poses[0].orientation.y, msg->poses[0].orientation.z, msg->poses[0].orientation.w);

    if(!canStamp)
      canStamp = true;

    transform.setOrigin(  tran_tag );
    transform.setRotation( quat_tag );
    
    br.sendTransform(tf::StampedTransform(transform, head_tag.stamp, head_tag.frame_id, nameTag));

    ROS_INFO("TAG -> Received and published tag pose from detection seq# %d", head_tag.seq);

  }
  catch (std::exception e)
  {
      ROS_ERROR("TAG -> Error! No message in input");
      return;
  }
}


int main(int argc, char **argv)
{
  
  ros::init(argc, argv, "Keep_tag_living_node");
  ros::NodeHandle nh_tag;

  std::string input_name_tag;
  nh_tag.param("keep_tag_living/name_tag", input_name_tag, std::string("/tag_0"));
  nameTag = input_name_tag.c_str();
  ROS_WARN("TAG -> Got param name_tag: %s", input_name_tag.c_str());

  std::string input_topic;
  nh_tag.param("keep_tag_living/input_topic", input_topic, std::string("/tag_detections_pose"));
  ROS_WARN("TAG -> Got param input_topic: %s", input_topic.c_str());
  
  ros::Subscriber sub = nh_tag.subscribe(input_topic.c_str(), 100, listenerTag);

  ros::spin();

  return 0;
}
